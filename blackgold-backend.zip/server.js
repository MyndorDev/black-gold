require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const authRoutes = require('./routes/auth');
const investRoutes = require('./routes/invest');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Connexion MongoDB
const { MONGO_URI } = require('./config/db');
mongoose.connect(MONGO_URI)
  .then(() => console.log('MongoDB connecté'))
  .catch(err => console.error(err));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/invest', investRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Serveur démarré sur le port ${PORT}`));
