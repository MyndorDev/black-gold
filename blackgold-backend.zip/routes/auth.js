const express = require('express');
const router = express.Router();
const authController = require('../controllers/auth.controller');
const { check } = require('express-validator');

router.post('/register', [
  check('email').isEmail().normalizeEmail(),
  check('password').isLength({ min: 6 })
], authController.register);

router.post('/login', authController.login);

module.exports = router;