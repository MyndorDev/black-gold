module.exports = {
  MONGO_URI: process.env.MONGO_URI || 'mongodb://localhost:27017/blackgold',
  JWT_SECRET: process.env.JWT_SECRET || 'tokensecret',
  PORT: process.env.PORT || 5000
};